This project was bootstrapped with Create React App.

Clone repo with "git clone https://github.com/chaninator/my-suppliers.git"

Run "npm install" in your terminal.

To start app run "npm start"

Here is a deployed version of the app that works:

http://my-suppliers.surge.sh/
